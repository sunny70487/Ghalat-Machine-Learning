Ghalat Machine Learning

Everything will be updated soon.
